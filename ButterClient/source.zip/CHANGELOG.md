# Changelog

## 1.1.0
- Reworked the Click GUI into a purple/dark category-based layout.
- Added HUD controls for CPS, ping, direction, keystrokes and armor durability.
- Added hold-C zoom and made Fullbright restore the previous gamma setting.
- Renamed the forward-key sprint helper to Auto Sprint for clarity.
- Removed the Awareness/cheat feature scope entirely.
- Marked unfinished World/Cosmetics/Combat/Environment items as planned instead of exposing fake toggles.
- Updated the Fabric 1.21.11 toolchain versions.

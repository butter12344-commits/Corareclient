package com.butterclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public final class ButterConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File CONFIG_FILE = FabricLoader.getInstance().getConfigDir().resolve("butterclient.json").toFile();

    public static Data data = new Data();

    public static final class Data {
        // Interface
        public boolean customMainMenu = true;
        public boolean showWelcomeText = true;
        public boolean purpleTheme = true;

        // HUD modules
        public boolean hudEnabled = true;
        public boolean showWatermark = true;
        public boolean showInGameWelcome = false;
        public boolean showFps = true;
        public boolean showCoordinates = true;
        public boolean showSprintStatus = true;
        public boolean showPing = true;
        public boolean showCps = true;
        public boolean showDirection = true;
        public boolean showKeystrokes = true;
        public boolean showArmor = true;

        // HUD position
        public int hudX = 10;
        public int hudY = 10;

        // Visual / utility modules
        public boolean fullbright = false;
        public boolean autoSprint = false;
        public boolean butterParticles = false;
        public boolean zoom = true;
        public double zoomLevel = 0.25;

        // Cosmetic HUD style
        public boolean roundedPanel = true;
        public boolean compactHud = false;
    }

    private ButterConfig() {}

    public static void load() {
        if (!CONFIG_FILE.exists()) {
            save();
            return;
        }
        try (FileReader reader = new FileReader(CONFIG_FILE)) {
            Data loaded = GSON.fromJson(reader, Data.class);
            if (loaded != null) data = loaded;
        } catch (IOException | RuntimeException e) {
            System.err.println("[Butter Client] Could not load config: " + e.getMessage());
        }
    }

    public static void save() {
        try {
            File parent = CONFIG_FILE.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                throw new IOException("Could not create config directory");
            }
            try (FileWriter writer = new FileWriter(CONFIG_FILE)) {
                GSON.toJson(data, writer);
            }
        } catch (IOException e) {
            System.err.println("[Butter Client] Could not save config: " + e.getMessage());
        }
    }
}

package com.butterclient.module;

import java.util.ArrayDeque;
import java.util.Deque;

public final class CpsCounter {
    private static final Deque<Long> CLICKS = new ArrayDeque<>();
    private CpsCounter() {}

    public static synchronized void registerClick() {
        long now = System.currentTimeMillis();
        CLICKS.addLast(now);
        prune(now);
    }

    public static synchronized int getCps() {
        long now = System.currentTimeMillis();
        prune(now);
        return CLICKS.size();
    }

    private static void prune(long now) {
        while (!CLICKS.isEmpty() && now - CLICKS.peekFirst() > 1000L) CLICKS.removeFirst();
    }
}

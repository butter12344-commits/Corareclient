package com.butterclient.mixin;

import com.butterclient.config.ButterConfig;
import com.butterclient.gui.ButterClickGuiScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
    private static final int PURPLE = 0xFFB58CFF;

    protected TitleScreenMixin(Text title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void butter$addSettingsButton(CallbackInfo ci) {
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§dButter Client"), button ->
                MinecraftClient.getInstance().setScreen(new ButterClickGuiScreen()))
                .dimensions(this.width - 118, 8, 110, 20).build());
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void butter$renderWelcome(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!ButterConfig.data.customMainMenu || !ButterConfig.data.showWelcomeText) return;
        MinecraftClient client = MinecraftClient.getInstance();
        String playerName = client.getSession() != null ? client.getSession().getUsername() : "Player";
        String welcome = "Welcome, " + playerName;
        String subtitle = "Butter Client 1.21.11  •  Right Shift to open GUI";
        int boxWidth = Math.max(textRenderer.getWidth(welcome), textRenderer.getWidth(subtitle)) + 24;
        int boxX = (width - boxWidth) / 2;
        context.fill(boxX, 8, boxX + boxWidth, 42, 0xD9141020);
        context.fill(boxX, 8, boxX + 2, 42, PURPLE);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("§d§l" + welcome), width / 2, 14, PURPLE);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("§7" + subtitle), width / 2, 28, 0xFFFFFFFF);
    }
}

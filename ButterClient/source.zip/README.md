# Butter Client 1.1.0 — Minecraft Java 1.21.11 / Fabric

A purple-themed client-side visual and quality-of-life mod. This project deliberately excludes cheat/awareness features such as ESP, tracers, freecam, radar, anti-vanish and storage/player tracking.

## Requirements
- Minecraft Java Edition 1.21.11
- Fabric Loader 0.19.5 or newer
- Fabric API 0.141.6+1.21.11
- Java 21

## Controls
- **Right Shift**: open/close Butter Client Click GUI
- **C**: hold to zoom (toggleable in Extra)

## Implemented modules
- **HUD**: watermark, welcome text, FPS, CPS, XYZ, ping, facing direction, sprint state, armor durability, keystrokes; HUD position editor; compact panel option.
- **Visuals**: Fullbright (restores the previous gamma value when disabled), sprint trail particles, purple panel style.
- **Extra**: hold-to-zoom and forward-key auto-sprint.
- **Interface**: purple/dark Click GUI with category navigation and persistent JSON settings.
- **Main menu**: Butter Client settings button and welcome banner.

## Categories in the GUI
HUD, Visuals, World, Cosmetics, Combat, Environment, Extra, Configs. Categories without implemented modules are marked as planned; they do not contain fake working toggles.

## Build
Run `gradle build --no-daemon` with Gradle 9.7.1 and Java 21. The installable remapped mod JAR is generated in `build/libs/` (do not use the `-sources.jar`). GitHub Actions can build it using **Actions → Build Butter Client (.jar) → Run workflow**.

## Configuration
`config/butterclient.json`

## Not included by design
Awareness/ESP, player or storage tracking, tracers, freecam, radar, anti-vanish, or other cheat modules.

## Important status
The source has been updated for the 1.21.11 Fabric toolchain, but this workspace could not download Gradle/dependencies, so a successful compile and in-game runtime test have not yet been verified. Do not treat an unbuilt source archive as an installable JAR.
